Run `npm run preview` for the 8k (zipped) production version 
