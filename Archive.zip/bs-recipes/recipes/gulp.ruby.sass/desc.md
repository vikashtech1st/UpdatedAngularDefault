
This example highlights both the stream support for injecting CSS, aswell
as the support for calling `reload` directly following html changes. 

We also need to filter out any source maps created by ruby-sass.